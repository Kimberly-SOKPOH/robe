---
title: 3 circle fill
categories:
  - Shapes
tags:
  - number
  - numeral
---
