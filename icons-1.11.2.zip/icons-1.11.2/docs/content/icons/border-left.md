---
title: Border left
categories:
  - UI and keyboard
tags:
  - borders
---
