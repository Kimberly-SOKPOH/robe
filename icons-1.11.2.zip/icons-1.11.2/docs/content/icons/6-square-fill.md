---
title: 6 square fill
categories:
  - Shapes
tags:
  - number
  - numeral
---
